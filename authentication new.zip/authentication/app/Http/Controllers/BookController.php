<?php
namespace App\Http\Controllers;
use DB;
use App\Book;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Request;
use View;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
class BookController extends Controller {

    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        //
        $books=Book::all();
        return view('books.index',compact('books'));


    }

    public function create()
    {
        return View::make('books.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */

    public function store()
    {
        $book=Input::all();
        Book::create($book);
        return redirect('books');
    }
    public function show($id)
    {
        $book=Book::find($id);
        return view('books.show',compact('book'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        $book=Book::find($id);
        return view('books.edit',compact('book'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update($id)
    {
        //
        $bookUpdate=Request::all();
        $book=Book::find($id);
        $book->update($bookUpdate);
        return redirect('books');
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        Book::find($id)->delete();
        return redirect('books');
    }
}