<html>
<body>
        <form align="right" name="form1" method="post" action="/logout">
            <button type="submit">Logout !</button>
            {{--{{$result[0]->password}}--}}

            <input type="hidden" name="_token" value="{{ csrf_token() }}">
        </form>



<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-body">
                <div class="text-right">

                </div>
                <form>
                <div class="table-responsive">

                        <table border="1" style="width:100%">
                        <thead>
                        <tr>

                            <th>firstname</th>
                            <th>lastname</th>
                            <th>username</th>
                            <th>email</th>
                            <th>website</th>
                            <th>phone</th>
                            <th>address</th>
                            <th>Image</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                         @foreach ($result as $userDetails)
                        <tr>

                            <td>{{$userDetails->firstname}}</td>
                            <td>{{$userDetails->lastname}}</td>
                            <td>{{$userDetails->username}}</td>
                            <td>{{$userDetails->email}}</td>
                            <td>{{$userDetails->website}}</td>
                            <td>{{$userDetails->phone}}</td>
                            <td>{{$userDetails->address}}</td>
                            <td><img src="{{$userDetails->image}}" height="50" width="80" class="img-rounded"></td>
                            <td>


                                <a href="/edit/<?php echo $userDetails->id ?>"
                                   data-id="<?php echo $userDetails->id ?>" id=""
                                   class="btn btn-warning">Update</a>
                                <a href="/destroy/<?php echo $userDetails->id ?>"
                                   data-id="<?php echo $userDetails->id ?>" id=""
                                   class="btn btn-danger">Delete</a>
                            </td>
                        </tr>

                       @endforeach

                        </tbody>
                            </table>

                </div>
                    </form>

            </div>
        </div>
    </div>
    <!-- /.col -->
</div>
<!-- /.row -->









</body>
</html>