
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-body">
                <div class="text-right">

                </div>
                <form action="/update" method="post" enctype="multipart/form-data">
                    <div class="table-responsive">

                        <table border="1" style="width:100%">
                            <thead>
                            <tr>
                                <th>id</th>
                                <th>firstname</th>
                                <th>lastname</th>
                                <th>username</th>
                                <th>email</th>
                                <th>website</th>
                                <th>phone</th>
                                <th>address</th>
                                <th>Action</th>


                            </tr>
                            </thead>
                            <tbody>


                                <tr>
                                    <td><input type = "text" name="id" value="{{$userDetails->id}}"></td>
                                    <td><input type = "text" name="updatefirstname" value="{{$userDetails->firstname}}"></td>
                                    <td><input type = "text" name="updatelastname" value="{{$userDetails->lastname}}"></td>
                                    <td><input type = "text" name="updateusername" value="{{$userDetails->username}}"></td>
                                    <td><input type = "text" name="updateemail" value="{{$userDetails->email}}"></td>
                                    <td><input type = "text" name="updatewebsite" value="{{$userDetails->website}}"></td>
                                    <td><input type = "text" name="updatephone" value="{{$userDetails->phone}}"></td>
                                    <td><input type = "text" name="updateaddress" value="{{$userDetails->address}}"></td>
                                    <td><input type="submit" name="submit" value="Update"/></td>
                                </tr>


                                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                            </tbody>
                        </table>

                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /.col -->
</div>
<!-- /.row -->
