<?php
namespace App\Http\Controllers;
use DB;
use App\User;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Request;
use View;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
//class UserController extends Controller {
//
//    /**
//     * Display a listing of the resource.
//     *
//     * @return Response
//     */
//    public function index()
//    {
//        //
//        $books=User::all();
//        return view('users.index',compact('books'));
//
//
//    }
//
//    public function create()
//    {
//        return View::make('books.create');
//    }
//
//    /**
//     * Store a newly created resource in storage.
//     *
//     * @return Response
//     */
//
//    public function store()
//    {
//        $book=Input::all();
//        Book::create($book);
//        return redirect('books');
//    }
//    public function show($id)
//    {
//        $book=Book::find($id);
//        return view('books.show',compact('book'));
//    }
//
//    /**
//     * Show the form for editing the specified resource.
//     *
//     * @param  int  $id
//     * @return Response
//     */
//    public function edit($id)
//    {
//        $book=Book::find($id);
//        return view('books.edit',compact('book'));
//    }
//
//    /**
//     * Update the specified resource in storage.
//     *
//     * @param  int  $id
//     * @return Response
//     */
//    public function update($id)
//    {
//        //
//        $bookUpdate=Request::all();
//        $book=Book::find($id);
//        $book->update($bookUpdate);
//        return redirect('books');
//    }
//    /**
//     * Remove the specified resource from storage.
//     *
//     * @param  int  $id
//     * @return Response
//     */
//    public function destroy($id)
//    {
//        Book::find($id)->delete();
//        return redirect('books');
//    }
//}


class UserController extends Controller
{
    public function index()
    {
        //
        $users = User::all();
        return view('users.index', compact('users'));


    }

    public function create()
    {
        return view::make('users.register');
    }


    public function store()
    {
        $users = Input::all();
        user::create($users);
        return redirect('users');
    }

    public function show($id)
    {
        $users = User::find($id);
        return view('users.register', compact('users'));

    }
//    public function edit($id)
//    {
//        $users=User::find($id);
//        return view('users.edit',compact('book'));
//    }
//    public function update($id)
//    {
//        //
//        $bookUpdate=Request::all();
//        $book=Book::find($id);
//        $book->update($bookUpdate);
//        return redirect('books');
//    }
//    public function destroy($id)
//    {
//        Book::find($id)->delete();
//        return redirect('books');
//    }


//    public function login()
//    {
//
//
//        $users = Input::all();
//        // Applying validation rules.
//        $rules = array(
//            'username' => 'required|username',
//            'password' => 'required|min:6',
//        );
//        $validator = Validator::make($users, $rules);
//        if ($validator->fails()) {
//            // If validation falis redirect back to login.
//            return Redirect::to('/index')->withInput(Input::except('password'))->withErrors($validator);
//        } else {
//            $userdata = array(
//                'email' => Input::get('email'),
//                'password' => Input::get('password')
//            );
//            // doing login.
//            if (Auth::validate($userdata)) {
//                if (Auth::attempt($userdata)) {
//                    return Redirect::intended('/books/index');
//                }
//            } else {
//                // if any error send back with message.
//                Session::flash('error', 'Something went wrong');
//                return Redirect::to('/index');
//            }
//        }
//
//    }
//}


    public function postLogin()
    {
        // Get all the inputs
        $userdata = array(
            'email' => Input::get('email'),
            'password' => Input::get('password')
        );

        // Declare the rules for the form validation.
        $rules = array(
            'email' => 'Required',
            'password' => 'Required'
        );

        // Validate the inputs.
        $validator = Validator::make($userdata, $rules);

        // Check if the form validates with success.
        if ($validator->passes()) {
            // Try to log the user in.
            if (Auth::attempt($userdata)) {
                // Redirect to intended page,
                // notice this only works if we redirected to the login page using Redirect::guest(...)
                return Redirect::intended('/')->with('success', 'You have logged in successfully');
            } else {
                // Redirect to the login page.
                return Redirect::to('login')->withErrors(array('password' => 'Password invalid'))->withInput(Input::except('password'));
            }
        }

        // Something went wrong.
        return Redirect::to('login')->withErrors($validator)->withInput(Input::except('password'));
    }
}




