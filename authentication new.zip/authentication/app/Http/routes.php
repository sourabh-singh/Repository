<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

//Route::get('/', function () {
//});
//Route::get('login',array)
//    'as' => 'login'
//
//Route::get('/index', function () {
//    return view('index');
//});
//Route::resource('/users','userController');
Route::resource('/register','Controller@register');
Route::resource('/login','Controller@login');
Route::resource('/add-user','Controller@addUser');
Route::get('/show','Controller@show');
Route::resource('/logout','Controller@logout');
Route::resource('/destroy','Controller@destroy');
Route::resource('/update','Controller@update');
Route::resource('edit', 'Controller@edit');



//// GET route
//Route::get('/login', function() {
//    return View::make('login');
//});
////POST route
//Route::post('login', 'AccountController@login');



//Route::get('/register', 'UserController@showUserRegistration');