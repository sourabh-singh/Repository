<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use DB;

class User extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'firstname', 'lastname', 'username', 'password', 'email', 'website', 'phone','fileToUpload', 'address'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];


    public function addUser()
    {
        if (func_num_args() > 0) {
            $userData = func_get_arg(0);
            try {
                $result = DB::table('users')
                    ->insert($userData);
                return $result;
            } catch (\Exception $e) {
                return $e->getMessage();
            }
        }
    else{
        echo 'value not passed';
    }
    }

public function getUserById($userId)
{
    $result = User::whereId($userId)->first();
    return $result;
}

  public function getUserData(){
      $result= DB::table('users')
      ->get();
      return $result;
  }

    public function UpdateUserDetails()
    {
        if (func_num_args() > 0) {
            $userData = func_get_arg(0);
            $userid = func_get_arg(1);
            try {
                $result = DB::table('users')
                    ->where('id', $userid)
                    ->update($userData);
                return $result;
            } catch (\Exception $e) {
                return $e->getMessage();
            }
        }
        else{
            echo 'value not passed';
        }
    }
}