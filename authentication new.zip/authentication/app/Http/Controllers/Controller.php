<?php

namespace App\Http\Controllers;
use DB;
use Session;
use Input;
use Response;
use App\User;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesResources;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class Controller extends BaseController
{
    use AuthorizesRequests, AuthorizesResources, DispatchesJobs, ValidatesRequests;

    public function register(Request $request)
    {
        return view("/users/register");
    }

    public function addUser(Request $request)
    {
        if ($request->isMethod('post')) {
            $userData['firstname'] = $request->input('firstname');

            $userData['lastname'] = $request->input('lastname');
            $userData['username'] = $request->input('username');
            $userData['password'] = Hash::make($request->input('password'));
            $userData['email'] = $request->input('email');
            $userData['website'] = $request->input('website');
            $userData['phone'] = $request->input('phone');

            $userData['address'] = $request->input('address');



            $target_dir = "uploads/";
//            print_r($target_dir);
//            die;
            $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
            $uploadOk = 1;
            $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
            if(isset($_POST["submit"])) {
                $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
                if($check !== false) {
                    echo "File is an image - " . $check["mime"] . ".";
                    $uploadOk = 1;
                } else {
                    echo "File is not an image.";
                    $uploadOk = 0;
                }
            }
// Check if file already exists
            if (file_exists($target_file)) {
                echo "Sorry, file already exists.";
                $uploadOk = 0;
            }
// Check file size
            if ($_FILES["fileToUpload"]["size"] > 50000000000000) {
                echo "Sorry, your file is too large.";
                $uploadOk = 0;
            }
// Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
                && $imageFileType != "gif" ) {
                echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
            }
// Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
            } else {
                if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
//                    echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
                } else {
                    echo "Sorry, there was an error uploading your file.";
                }
            }

            $userData['image'] =$target_file;

            $objInsertData = new User();

            $result = $objInsertData->addUser($userData);
            if ($result) {
//                die('data inserted');
//                return view("/users/login");
//
//            }
        }

        return view("/users/login");




    }}


    public function login(Request $request)
    {

        if (Session::has('user')) {
            return redirect('/show');
        }
        if ($request->isMethod('post')) {
            $username = $request->input('username');
            $password = $request->input('password');
            if (Auth::attempt(['username' => $username, 'password' => $password])) {
//                die('hello');
                $objModelUsers = new User();
                $userDetails = $objModelUsers->getUserById(Auth::id());
                $sessionName = 'user';
                Session::put($sessionName, $userDetails['original']);

                return redirect()->intended('/show');
//                echo '<pre>';
//                print_r($userDetails);
//                die;
            } else {
                die('invalid');
//                return Redirect::back()->with(['status' => 'error', 'msg' => 'invalid creds.']);
            }
        }
        return view("users/login");
            }



    public function show(Request $request)
    {

//        $data = $request->session()->all();
//        echo '<pre>';
//        print_r($data['user']);
//        die;
        $objData= new User();
        $result =$objData->getUserData();

        return view('/users/show',['result' => $result]);
    }




    public function logout()
    {
        Session::forget('user');
//        Session::flush('user');
        return redirect('/login');
    }

    public function update(Request $request)
    {
        $userData['firstname'] = $request->input('updatefirstname');
        $userData['lastname'] = $request->input('updatelastname');
        $userData['username'] = $request->input('updateusername');
        $userData['email'] = $request->input('updateemail');
        $userData['website'] = $request->input('updatewebsite');
        $userData['phone'] = $request->input('updatephone');
        $userData['address'] = $request->input('updateaddress');

        $userid = $request->input('id');
//        print_r($userData);die;
//        $Update=Request::all();
        $objModelUsers = new User();
        $userDetails = $objModelUsers->UpdateUserDetails($userData,$userid);
//
//        $userDetails=User::find($id);
//        $userDetails->update($Update);
        return redirect('/show');
    }

    public function destroy($userDetails)
    {
        User::find($userDetails)->delete();
        return redirect('show');
    }

    public function edit($id){
        $userDetails=User::find($id);

        return view('/users/edit',compact('userDetails'));

//        print_r($id);
//        die;
    }

}


